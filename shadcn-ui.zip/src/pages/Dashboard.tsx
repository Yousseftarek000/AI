import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useNavigate } from "react-router-dom";
import { 
  Plus, 
  Play, 
  Sparkles, 
  TrendingUp, 
  Clock,
  Video,
  Zap,
  Crown,
  Search,
  Filter
} from "lucide-react";

export default function Dashboard() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");

  const recentProjects = [
    {
      id: 1,
      title: "5 Morning Habits for Success",
      thumbnail: "/api/placeholder/300/200",
      duration: "0:45",
      status: "completed",
      views: "12.5K",
      engagement: "+127%"
    },
    {
      id: 2,
      title: "Crypto Trading Tips",
      thumbnail: "/api/placeholder/300/200",
      duration: "1:20",
      status: "rendering",
      views: "0",
      engagement: "N/A"
    },
    {
      id: 3,
      title: "Productivity Hacks",
      thumbnail: "/api/placeholder/300/200",
      duration: "0:38",
      status: "completed",
      views: "8.2K",
      engagement: "+95%"
    }
  ];

  const quickTemplates = [
    {
      id: 1,
      name: "Motivational Quote",
      category: "Trending",
      thumbnail: "/api/placeholder/200/300",
      uses: "15.2K"
    },
    {
      id: 2,
      name: "Life Hack Tutorial",
      category: "Educational",
      thumbnail: "/api/placeholder/200/300",
      uses: "22.1K"
    },
    {
      id: 3,
      name: "Success Tips",
      category: "Business",
      thumbnail: "/api/placeholder/200/300",
      uses: "18.7K"
    },
    {
      id: 4,
      name: "Daily Affirmations",
      category: "Wellness",
      thumbnail: "/api/placeholder/200/300",
      uses: "11.3K"
    }
  ];

  const stats = [
    { label: "Total Videos", value: "24", change: "+12" },
    { label: "Total Views", value: "156.8K", change: "+45.2K" },
    { label: "Avg Engagement", value: "127%", change: "+23%" },
    { label: "Viral Videos", value: "8", change: "+3" }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="flex justify-between items-center p-6 max-w-7xl mx-auto">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center glow-effect">
              <span className="text-white font-bold text-xl">V</span>
            </div>
            <span className="text-xl font-bold gradient-text">Viral AI Studio</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <Badge className="gradient-primary border-0 text-white">
              <Crown className="w-4 h-4 mr-1" />
              Premium Free
            </Badge>
            <Button 
              className="gradient-primary hover:opacity-90 glow-effect"
              onClick={() => navigate('/editor')}
            >
              <Plus className="w-4 h-4 mr-2" />
              New Video
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">
            Welcome back! 👋
          </h1>
          <p className="text-gray-300 text-lg">
            Ready to create your next viral video?
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="text-2xl font-bold gradient-text mb-1">{stat.value}</div>
                <div className="text-gray-400 text-sm mb-2">{stat.label}</div>
                <div className="text-green-400 text-xs flex items-center">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  {stat.change}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-purple-600/20 to-cyan-600/20 border-purple-500/30 cursor-pointer hover:scale-105 transition-transform"
                onClick={() => navigate('/editor?mode=ai')}>
            <CardContent className="p-8 text-center">
              <Sparkles className="w-12 h-12 mx-auto mb-4 text-purple-400" />
              <h3 className="text-xl font-bold mb-2">AI Generate</h3>
              <p className="text-gray-300">Create with AI prompts</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-cyan-600/20 to-blue-600/20 border-cyan-500/30 cursor-pointer hover:scale-105 transition-transform"
                onClick={() => navigate('/templates')}>
            <CardContent className="p-8 text-center">
              <Video className="w-12 h-12 mx-auto mb-4 text-cyan-400" />
              <h3 className="text-xl font-bold mb-2">Use Template</h3>
              <p className="text-gray-300">Browse 1000+ templates</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-600/20 to-orange-600/20 border-yellow-500/30 cursor-pointer hover:scale-105 transition-transform"
                onClick={() => navigate('/editor?mode=blank')}>
            <CardContent className="p-8 text-center">
              <Zap className="w-12 h-12 mx-auto mb-4 text-yellow-400" />
              <h3 className="text-xl font-bold mb-2">Start Blank</h3>
              <p className="text-gray-300">Build from scratch</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="recent" className="space-y-6">
          <TabsList className="bg-slate-800 border-slate-700">
            <TabsTrigger value="recent">Recent Projects</TabsTrigger>
            <TabsTrigger value="templates">Quick Templates</TabsTrigger>
          </TabsList>

          <TabsContent value="recent" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Recent Projects</h2>
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                  <Input 
                    placeholder="Search projects..."
                    className="pl-10 bg-slate-800 border-slate-700"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <Button variant="outline" className="border-slate-700">
                  <Filter className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {recentProjects.map((project) => (
                <Card key={project.id} className="bg-slate-800/50 border-slate-700 cursor-pointer hover:bg-slate-800/70 transition-all group">
                  <div className="relative">
                    <div className="w-full h-48 bg-slate-700 rounded-t-lg flex items-center justify-center">
                      <Play className="w-12 h-12 text-gray-400 group-hover:text-white transition-colors" />
                    </div>
                    <Badge className={`absolute top-2 right-2 ${
                      project.status === 'completed' ? 'bg-green-600' : 'bg-yellow-600'
                    }`}>
                      {project.status}
                    </Badge>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-2 truncate">{project.title}</h3>
                    <div className="flex justify-between items-center text-sm text-gray-400">
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4" />
                        <span>{project.duration}</span>
                      </div>
                      <div className="text-right">
                        <div>{project.views} views</div>
                        <div className="text-green-400">{project.engagement}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="templates" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Quick Templates</h2>
              <Button 
                variant="outline" 
                className="border-slate-700"
                onClick={() => navigate('/templates')}
              >
                View All Templates
              </Button>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {quickTemplates.map((template) => (
                <Card key={template.id} className="bg-slate-800/50 border-slate-700 cursor-pointer hover:bg-slate-800/70 transition-all group">
                  <div className="w-full h-48 bg-slate-700 rounded-t-lg flex items-center justify-center">
                    <Play className="w-12 h-12 text-gray-400 group-hover:text-white transition-colors" />
                  </div>
                  <CardContent className="p-4">
                    <Badge className="mb-2 text-xs" variant="secondary">{template.category}</Badge>
                    <h3 className="font-semibold mb-2 truncate">{template.name}</h3>
                    <div className="text-sm text-gray-400">{template.uses} uses</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}