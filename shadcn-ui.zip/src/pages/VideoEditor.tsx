import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { useNavigate } from "react-router-dom";
import { 
  Play, 
  Pause,
  Download,
  Share2,
  Sparkles,
  Wand2,
  Eye,
  Clock,
  Heart,
  MessageCircle,
  Send,
  Copy,
  ArrowLeft,
  Settings,
  Layers,
  Type,
  Music,
  Palette
} from "lucide-react";

export default function VideoEditor() {
  const navigate = useNavigate();
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState(0);
  const [videoGenerated, setVideoGenerated] = useState(false);
  const [aiPrompt, setAiPrompt] = useState("");
  const [generatedCaption, setGeneratedCaption] = useState("");
  const [generatedHashtags, setGeneratedHashtags] = useState<string[]>([]);

  const handleGenerateVideo = async () => {
    if (!aiPrompt.trim()) return;
    
    setIsGenerating(true);
    setGenerationProgress(0);
    
    // Simulate AI generation process
    const steps = [
      { progress: 20, message: "Analyzing your prompt..." },
      { progress: 40, message: "Generating video scenes..." },
      { progress: 60, message: "Adding AI voiceover..." },
      { progress: 80, message: "Optimizing for Instagram..." },
      { progress: 100, message: "Video ready!" }
    ];
    
    for (const step of steps) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setGenerationProgress(step.progress);
    }
    
    setVideoGenerated(true);
    setIsGenerating(false);
    
    // Generate mock caption and hashtags
    setGeneratedCaption("🔥 Ready to transform your morning routine? These 5 simple habits will change your life forever! Which one will you try first? 💪✨");
    setGeneratedHashtags([
      "#morningroutine", "#productivity", "#success", "#mindset", "#motivation",
      "#selfimprovement", "#lifehacks", "#wellness", "#goals", "#inspiration",
      "#entrepreneurship", "#growthmindset", "#positivity", "#discipline", "#focus",
      "#healthyhabits", "#successmindset", "#personaldevelopment", "#leadership", "#hustle",
      "#workoutmotivation", "#mentalhealth", "#confidence", "#achievement", "#progress",
      "#transformation", "#lifestyle", "#mindfulness", "#ambition", "#dedication",
      "#resilience", "#excellence", "#breakthrough", "#potential", "#unstoppable"
    ]);
  };

  const mockVideoMetrics = {
    duration: "0:45",
    estimatedViews: "15.2K - 28.7K",
    viralScore: 89,
    engagementRate: "+127%"
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="flex justify-between items-center p-6 max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/dashboard')}
              className="text-gray-300 hover:text-white"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
            <Separator orientation="vertical" className="h-6" />
            <span className="text-lg font-semibold">AI Video Editor</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <Badge className="gradient-primary border-0 text-white">
              <Eye className="w-4 h-4 mr-1" />
              Preview Mode
            </Badge>
            {videoGenerated && (
              <>
                <Button variant="outline" className="border-slate-700">
                  <Share2 className="w-4 h-4 mr-2" />
                  Share
                </Button>
                <Button className="gradient-primary hover:opacity-90 glow-effect">
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </>
            )}
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-80px)]">
        {/* Left Sidebar - AI Generation */}
        <div className="w-80 border-r border-slate-800 bg-slate-900/30 p-6 overflow-y-auto">
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <Sparkles className="w-5 h-5 mr-2 text-purple-400" />
                AI Video Generation
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Video Topic</label>
                  <Textarea
                    placeholder="Describe your video idea... (e.g., '5 morning habits for success')"
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    className="bg-slate-800 border-slate-700 min-h-[100px]"
                  />
                </div>

                <Button 
                  onClick={handleGenerateVideo}
                  disabled={isGenerating || !aiPrompt.trim()}
                  className="w-full gradient-primary hover:opacity-90 glow-effect"
                >
                  {isGenerating ? (
                    <>
                      <Wand2 className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Wand2 className="w-4 h-4 mr-2" />
                      Generate Video
                    </>
                  )}
                </Button>

                {isGenerating && (
                  <div className="space-y-2">
                    <Progress value={generationProgress} className="w-full" />
                    <p className="text-sm text-gray-400 text-center">
                      {generationProgress < 20 && "Analyzing your prompt..."}
                      {generationProgress >= 20 && generationProgress < 40 && "Generating video scenes..."}
                      {generationProgress >= 40 && generationProgress < 60 && "Adding AI voiceover..."}
                      {generationProgress >= 60 && generationProgress < 80 && "Optimizing for Instagram..."}
                      {generationProgress >= 80 && "Video ready!"}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {videoGenerated && (
              <>
                <Separator />
                <div>
                  <h4 className="font-medium mb-3">Video Metrics</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Duration:</span>
                      <span>{mockVideoMetrics.duration}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Est. Views:</span>
                      <span className="text-green-400">{mockVideoMetrics.estimatedViews}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Viral Score:</span>
                      <Badge className="bg-green-600">{mockVideoMetrics.viralScore}/100</Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Engagement:</span>
                      <span className="text-green-400">{mockVideoMetrics.engagementRate}</span>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Main Content - Video Preview */}
        <div className="flex-1 flex">
          <div className="flex-1 p-6">
            <div className="h-full flex items-center justify-center">
              {!videoGenerated ? (
                <Card className="bg-slate-800/50 border-slate-700 p-8 text-center max-w-md">
                  <CardContent>
                    <Sparkles className="w-16 h-16 mx-auto mb-4 text-purple-400" />
                    <h3 className="text-xl font-semibold mb-2">Ready to Create?</h3>
                    <p className="text-gray-400 mb-4">
                      Enter your video idea in the AI panel to generate your first viral video.
                    </p>
                    <div className="text-left space-y-2 text-sm text-gray-400">
                      <div>✨ AI-powered generation</div>
                      <div>🎯 Optimized for virality</div>
                      <div>📱 Instagram-ready format</div>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <div className="w-full max-w-md mx-auto">
                  <div className="aspect-[9/16] bg-slate-800 rounded-lg relative overflow-hidden border-2 border-slate-700">
                    {/* Mock Video Preview */}
                    <div className="absolute inset-0 gradient-primary opacity-20"></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <Play className="w-16 h-16 mb-4 mx-auto text-white opacity-80" />
                        <div className="text-white font-semibold">5 Morning Habits</div>
                        <div className="text-gray-300 text-sm">for Success</div>
                      </div>
                    </div>
                    
                    {/* Video Controls */}
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                      <div className="flex items-center space-x-4">
                        <Button size="sm" className="gradient-primary rounded-full p-2">
                          <Play className="w-4 h-4" />
                        </Button>
                        <div className="flex-1 bg-gray-600 h-1 rounded">
                          <div className="bg-white h-1 rounded w-1/3"></div>
                        </div>
                        <span className="text-white text-xs">0:15 / 0:45</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Sidebar - Caption & Hashtags */}
          <div className="w-80 border-l border-slate-800 bg-slate-900/30 p-6 overflow-y-auto">
            {videoGenerated && (
              <Tabs defaultValue="caption" className="w-full">
                <TabsList className="grid w-full grid-cols-2 bg-slate-800">
                  <TabsTrigger value="caption">Caption</TabsTrigger>
                  <TabsTrigger value="hashtags">Hashtags</TabsTrigger>
                </TabsList>
                
                <TabsContent value="caption" className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="font-medium">AI Generated Caption</h4>
                      <Button size="sm" variant="outline" className="border-slate-700">
                        <Wand2 className="w-3 h-3 mr-1" />
                        Regenerate
                      </Button>
                    </div>
                    <Textarea
                      value={generatedCaption}
                      onChange={(e) => setGeneratedCaption(e.target.value)}
                      className="bg-slate-800 border-slate-700 min-h-[120px]"
                    />
                    <div className="flex justify-between items-center mt-2 text-xs text-gray-400">
                      <span>{generatedCaption.length} characters</span>
                      <Button size="sm" variant="ghost">
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h5 className="text-sm font-medium">Engagement Preview</h5>
                    <div className="bg-slate-800 rounded-lg p-3 space-y-2">
                      <div className="flex items-center space-x-2 text-sm">
                        <Heart className="w-4 h-4 text-red-400" />
                        <span>12.5K - 18.2K likes</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm">
                        <MessageCircle className="w-4 h-4 text-blue-400" />
                        <span>850 - 1.2K comments</span>
                      </div>
                      <div className="flex items-center space-x-2 text-sm">
                        <Send className="w-4 h-4 text-green-400" />
                        <span>450 - 680 shares</span>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="hashtags" className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="font-medium">Smart Hashtags ({generatedHashtags.length})</h4>
                      <Button size="sm" variant="outline" className="border-slate-700">
                        <Wand2 className="w-3 h-3 mr-1" />
                        Regenerate
                      </Button>
                    </div>
                    
                    <div className="space-y-3">
                      <div>
                        <h5 className="text-sm font-medium mb-2 text-purple-400">Trending (High Volume)</h5>
                        <div className="flex flex-wrap gap-2">
                          {generatedHashtags.slice(0, 8).map((hashtag, index) => (
                            <Badge key={index} className="bg-purple-600/20 text-purple-300 hover:bg-purple-600/30 cursor-pointer">
                              {hashtag}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h5 className="text-sm font-medium mb-2 text-cyan-400">Niche Specific</h5>
                        <div className="flex flex-wrap gap-2">
                          {generatedHashtags.slice(8, 16).map((hashtag, index) => (
                            <Badge key={index} className="bg-cyan-600/20 text-cyan-300 hover:bg-cyan-600/30 cursor-pointer">
                              {hashtag}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h5 className="text-sm font-medium mb-2 text-yellow-400">Long Tail</h5>
                        <div className="flex flex-wrap gap-2">
                          {generatedHashtags.slice(16).map((hashtag, index) => (
                            <Badge key={index} className="bg-yellow-600/20 text-yellow-300 hover:bg-yellow-600/30 cursor-pointer">
                              {hashtag}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>

                    <Button className="w-full mt-4" variant="outline">
                      <Copy className="w-4 h-4 mr-2" />
                      Copy All Hashtags
                    </Button>
                  </div>
                </TabsContent>
              </Tabs>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}