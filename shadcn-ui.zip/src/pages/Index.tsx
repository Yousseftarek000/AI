import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { Play, Sparkles, Zap, Crown, Users, TrendingUp } from "lucide-react";

export default function Index() {
  const navigate = useNavigate();

  const features = [
    {
      icon: <Sparkles className="w-6 h-6" />,
      title: "AI Video Generation",
      description: "Create viral faceless videos with advanced AI in under 60 seconds"
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "Smart Captions & Hashtags",
      description: "Auto-generate engaging captions with 30+ trending hashtags"
    },
    {
      icon: <Crown className="w-6 h-6" />,
      title: "Premium Features Free",
      description: "Access all premium tools that competitors charge $50+/month for"
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "1000+ Templates",
      description: "Professional faceless video templates optimized for virality"
    },
    {
      icon: <TrendingUp className="w-6 h-6" />,
      title: "127% Higher Engagement",
      description: "Our AI optimizes content for maximum Instagram engagement"
    },
    {
      icon: <Play className="w-6 h-6" />,
      title: "Instagram Ready",
      description: "Export in perfect formats with scheduling and batch processing"
    }
  ];

  const stats = [
    { number: "100K+", label: "Videos Created" },
    { number: "50K+", label: "Creators" },
    { number: "127%", label: "Higher Engagement" },
    { number: "FREE", label: "Forever" }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-neon-pattern opacity-50" />
      
      {/* Header */}
      <header className="relative z-10 flex justify-between items-center p-6 max-w-7xl mx-auto">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center glow-effect">
            <span className="text-white font-bold text-xl">V</span>
          </div>
          <span className="text-xl font-bold gradient-text">Viral AI Studio</span>
        </div>
        
        <nav className="hidden md:flex items-center space-x-6">
          <Button variant="ghost" className="text-gray-300 hover:text-white">Features</Button>
          <Button variant="ghost" className="text-gray-300 hover:text-white">Templates</Button>
          <Button variant="ghost" className="text-gray-300 hover:text-white">Pricing</Button>
          <Button 
            className="gradient-primary hover:opacity-90 glow-effect"
            onClick={() => navigate('/dashboard')}
          >
            Get Started Free
          </Button>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="relative z-10 text-center py-20 px-6 max-w-7xl mx-auto">
        <Badge className="mb-6 gradient-primary border-0 text-white animate-glow">
          🔥 All Premium Features FREE Forever
        </Badge>
        
        <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
          Generate{" "}
          <span className="gradient-text animate-float inline-block">Viral Videos</span>
          <br />
          in 60 Seconds
        </h1>
        
        <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto leading-relaxed">
          Create professional faceless videos that go viral on Instagram. 
          AI-powered generation, smart captions, 30+ hashtags, and premium features - all completely free.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
          <Button 
            size="lg" 
            className="gradient-primary hover:opacity-90 glow-effect text-lg px-8 py-4 animate-glow"
            onClick={() => navigate('/dashboard')}
          >
            <Play className="w-5 h-5 mr-2" />
            Create Your First Video
          </Button>
          <Button 
            size="lg" 
            variant="outline" 
            className="border-purple-500 text-purple-400 hover:bg-purple-500/10 text-lg px-8 py-4"
            onClick={() => navigate('/templates')}
          >
            Browse Templates
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => (
            <Card key={index} className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardContent className="p-6 text-center">
                <div className="text-2xl md:text-3xl font-bold gradient-text mb-2">{stat.number}</div>
                <div className="text-gray-400 text-sm">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Features Section */}
      <section className="relative z-10 py-20 px-6 max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Everything Premium,{" "}
            <span className="gradient-text">Completely Free</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Access all the features that other platforms charge $50-$200/month for. 
            No limits, no watermarks, no credit card required.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="bg-slate-800/50 border-slate-700 backdrop-blur-sm hover:bg-slate-800/70 transition-all duration-300 group">
              <CardContent className="p-8">
                <div className="gradient-primary w-12 h-12 rounded-lg flex items-center justify-center mb-6 group-hover:glow-effect transition-all duration-300">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold mb-4 text-white">{feature.title}</h3>
                <p className="text-gray-300 leading-relaxed">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative z-10 py-20 px-6 text-center">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Ready to Go{" "}
            <span className="gradient-text">Viral?</span>
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Join 50,000+ creators who are already using Viral AI Studio to create engaging content.
          </p>
          <Button 
            size="lg" 
            className="gradient-primary hover:opacity-90 glow-effect text-lg px-12 py-4 animate-glow"
            onClick={() => navigate('/dashboard')}
          >
            Start Creating Now - It's Free!
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative z-10 border-t border-slate-800 py-12 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-2 mb-6">
            <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center glow-effect">
              <span className="text-white font-bold text-xl">V</span>
            </div>
            <span className="text-xl font-bold gradient-text">Viral AI Studio</span>
          </div>
          <p className="text-gray-400">
            Democratizing professional video creation for everyone.
          </p>
        </div>
      </footer>
    </div>
  );
}