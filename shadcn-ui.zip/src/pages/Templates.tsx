import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { 
  Search, 
  Filter, 
  Play, 
  Heart,
  Eye,
  TrendingUp,
  ArrowLeft,
  Crown,
  Sparkles
} from "lucide-react";

export default function Templates() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const categories = [
    { id: "all", name: "All Templates", count: 1247 },
    { id: "trending", name: "Trending Now", count: 156 },
    { id: "motivational", name: "Motivational", count: 234 },
    { id: "educational", name: "Educational", count: 189 },
    { id: "business", name: "Business", count: 167 },
    { id: "lifestyle", name: "Lifestyle", count: 145 },
    { id: "tech", name: "Tech Tips", count: 98 },
    { id: "fitness", name: "Fitness", count: 87 },
    { id: "finance", name: "Finance", count: 76 },
    { id: "quotes", name: "Quotes", count: 95 }
  ];

  const templates = [
    {
      id: 1,
      title: "Morning Routine Success",
      category: "motivational",
      thumbnail: "/api/placeholder/300/400",
      duration: "0:45",
      uses: "24.5K",
      engagement: "+145%",
      trending: true,
      premium: false
    },
    {
      id: 2,
      title: "Crypto Investment Guide",
      category: "finance",
      thumbnail: "/api/placeholder/300/400",
      duration: "1:20",
      uses: "18.2K",
      engagement: "+132%",
      trending: true,
      premium: false
    },
    {
      id: 3,
      title: "Productivity Life Hacks",
      category: "educational",
      thumbnail: "/api/placeholder/300/400",
      duration: "0:38",
      uses: "31.7K",
      engagement: "+189%",
      trending: false,
      premium: false
    },
    {
      id: 4,
      title: "AI Business Ideas",
      category: "business",
      thumbnail: "/api/placeholder/300/400",
      duration: "1:05",
      uses: "15.3K",
      engagement: "+156%",
      trending: true,
      premium: false
    },
    {
      id: 5,
      title: "Mindset Transformation",
      category: "motivational",
      thumbnail: "/api/placeholder/300/400",
      duration: "0:52",
      uses: "22.8K",
      engagement: "+167%",
      trending: false,
      premium: false
    },
    {
      id: 6,
      title: "Tech Career Tips",
      category: "tech",
      thumbnail: "/api/placeholder/300/400",
      duration: "1:15",
      uses: "19.4K",
      engagement: "+143%",
      trending: false,
      premium: false
    },
    {
      id: 7,
      title: "Fitness Motivation",
      category: "fitness",
      thumbnail: "/api/placeholder/300/400",
      duration: "0:33",
      uses: "27.1K",
      engagement: "+178%",
      trending: true,
      premium: false
    },
    {
      id: 8,
      title: "Daily Success Quotes",
      category: "quotes",
      thumbnail: "/api/placeholder/300/400",
      duration: "0:25",
      uses: "35.6K",
      engagement: "+134%",
      trending: false,
      premium: false
    },
    {
      id: 9,
      title: "Entrepreneurship Journey",
      category: "business",
      thumbnail: "/api/placeholder/300/400",
      duration: "1:30",
      uses: "13.9K",
      engagement: "+198%",
      trending: true,
      premium: false
    },
    {
      id: 10,
      title: "Healthy Lifestyle Tips",
      category: "lifestyle",
      thumbnail: "/api/placeholder/300/400",
      duration: "0:41",
      uses: "21.2K",
      engagement: "+125%",
      trending: false,
      premium: false
    },
    {
      id: 11,
      title: "Investment Strategies",
      category: "finance",
      thumbnail: "/api/placeholder/300/400",
      duration: "1:12",
      uses: "16.7K",
      engagement: "+169%",
      trending: false,
      premium: false
    },
    {
      id: 12,
      title: "Study Techniques",
      category: "educational",
      thumbnail: "/api/placeholder/300/400",
      duration: "0:58",
      uses: "29.3K",
      engagement: "+152%",
      trending: true,
      premium: false
    }
  ];

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      {/* Header */}
      <header className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="flex justify-between items-center p-6 max-w-7xl mx-auto">
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/dashboard')}
              className="text-gray-300 hover:text-white"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center glow-effect">
                <span className="text-white font-bold text-xl">V</span>
              </div>
              <span className="text-xl font-bold gradient-text">Templates</span>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <Badge className="gradient-primary border-0 text-white">
              <Crown className="w-4 h-4 mr-1" />
              All Premium Free
            </Badge>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6">
        {/* Hero Section */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            1000+ <span className="gradient-text">Viral Templates</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Professional video templates optimized for maximum engagement. 
            All premium features included for free.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input 
              placeholder="Search templates by topic, style, or category..."
              className="pl-10 bg-slate-800 border-slate-700 h-12"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Button variant="outline" className="border-slate-700 h-12 px-6">
            <Filter className="w-4 h-4 mr-2" />
            Advanced Filters
          </Button>
        </div>

        {/* Categories */}
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              className={selectedCategory === category.id 
                ? "gradient-primary border-0" 
                : "border-slate-700 hover:border-purple-500"
              }
              onClick={() => setSelectedCategory(category.id)}
            >
              {category.name} ({category.count})
            </Button>
          ))}
        </div>

        {/* Featured Templates */}
        {selectedCategory === "all" && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold flex items-center">
                <TrendingUp className="w-6 h-6 mr-2 text-orange-400" />
                Trending This Week
              </h2>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              {templates.filter(t => t.trending).slice(0, 4).map((template) => (
                <Card key={template.id} className="bg-slate-800/50 border-slate-700 cursor-pointer hover:bg-slate-800/70 transition-all group relative overflow-hidden">
                  <div className="absolute top-2 left-2 z-10">
                    <Badge className="bg-orange-600 text-white">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      Trending
                    </Badge>
                  </div>
                  <div className="w-full h-48 bg-slate-700 flex items-center justify-center relative">
                    <div className="absolute inset-0 gradient-primary opacity-20"></div>
                    <Play className="w-12 h-12 text-white group-hover:scale-110 transition-transform z-10" />
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-2 truncate">{template.title}</h3>
                    <div className="flex justify-between items-center text-sm text-gray-400 mb-2">
                      <span>{template.duration}</span>
                      <span className="text-green-400">{template.engagement}</span>
                    </div>
                    <div className="flex items-center space-x-4 text-xs text-gray-400">
                      <div className="flex items-center">
                        <Eye className="w-3 h-3 mr-1" />
                        {template.uses}
                      </div>
                      <Badge variant="secondary" className="text-xs">{template.category}</Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* All Templates Grid */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">
              {selectedCategory === "all" ? "All Templates" : categories.find(c => c.id === selectedCategory)?.name}
              <span className="text-gray-400 text-lg ml-2">({filteredTemplates.length})</span>
            </h2>
            <div className="flex items-center space-x-2 text-sm text-gray-400">
              <Sparkles className="w-4 h-4" />
              <span>All features included for free</span>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredTemplates.map((template) => (
              <Card 
                key={template.id} 
                className="bg-slate-800/50 border-slate-700 cursor-pointer hover:bg-slate-800/70 transition-all group relative overflow-hidden"
                onClick={() => navigate(`/editor?template=${template.id}`)}
              >
                {template.trending && (
                  <div className="absolute top-2 left-2 z-10">
                    <Badge className="bg-orange-600 text-white text-xs">
                      🔥 Hot
                    </Badge>
                  </div>
                )}
                <div className="absolute top-2 right-2 z-10">
                  <Badge className="bg-green-600 text-white text-xs">
                    FREE
                  </Badge>
                </div>
                
                <div className="w-full h-48 bg-slate-700 flex items-center justify-center relative">
                  <div className="absolute inset-0 gradient-primary opacity-20"></div>
                  <Play className="w-12 h-12 text-white group-hover:scale-110 transition-transform z-10" />
                </div>
                
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-2 truncate">{template.title}</h3>
                  <div className="flex justify-between items-center text-sm text-gray-400 mb-3">
                    <span>{template.duration}</span>
                    <span className="text-green-400">{template.engagement}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3 text-xs text-gray-400">
                      <div className="flex items-center">
                        <Eye className="w-3 h-3 mr-1" />
                        {template.uses}
                      </div>
                      <div className="flex items-center">
                        <Heart className="w-3 h-3 mr-1" />
                        Popular
                      </div>
                    </div>
                    <Badge variant="secondary" className="text-xs capitalize">{template.category}</Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Load More */}
        {filteredTemplates.length > 12 && (
          <div className="text-center">
            <Button variant="outline" className="border-slate-700">
              Load More Templates
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}